# Vom Antwortexport zum Skalierungsdatensatz.
# Für eigene Daten Pfade, Bereiche und Missing-Regeln anpassen.
# Mehrere Testzeitpunkte getrennt aufbereiten.

# 1. Pakete und Ausgabeordner

# ---- workflow-start ----
library(eatPrepTBA) # lädt eatAutoCode mit; nicht separat laden
library(dplyr)
library(tidyr)
person_columns <- c("group_id", "login_name", "login_code")

dir.create("outputs", showWarnings = FALSE)
dir.create("checkpoints", showWarnings = FALSE)
# ---- /workflow-start ----

# 2. Beispieldaten einlesen
# Den Abruf eigener Daten zeigt R/01_datenabruf.R.

# ---- daten-einlesen ----
units <- readRDS("data/units.rds")
design <- readRDS("data/design.rds")
responses <- read_responses("data/Responses.csv")

# Nach einem API-Abruf alternativ:
# responses <- readRDS("data_eigen/responses.rds")

count(responses, booklet_id)
saveRDS(responses, "checkpoints/01_responses.rds")
# ---- /daten-einlesen ----

# Units und Booklet-Reihenfolge ansehen.
# ---- studie-units-booklets-vorschau ----
print(units |> select(unit_key, unit_label)) # sollte 6 Units zeigen
print(readr::read_csv("data/booklets.csv", show_col_types = FALSE) |>
  select(booklet_id, unit_booklet_no, unit_key) |> head(5))
# ---- /studie-units-booklets-vorschau ----

# Im Design steht eine Zeile für eine vorgesehene Person und Variable.
# ---- design-rohdaten-vorschau ----
print(design |> select(login_name, booklet_id, unit_key, variable_id) |> head(6))
# ---- /design-rohdaten-vorschau ----

# Eine Antwortzeile enthält die Antworten einer Person auf eine Unit.
# ---- antwortdaten-vorschau ----
responses |>
  select(login_name, booklet_id, unit_key, response_progress) |>
  head(4) |> print()
# ---- /antwortdaten-vorschau ----

# Antworten mit Units und Testdesign abgleichen.
# Fehlende Antworten ergänzt später complete_design().

# ---- daten-abgleichen ----
response_keys <- c("group_id", "login_name", "login_code",
                  "booklet_id", "unit_key")

unknown_units <- anti_join(responses, units, by = "unit_key")
outside_design <- anti_join(responses, design, by = response_keys)
missing_rows <- anti_join(design, responses, by = response_keys)
# ---- /daten-abgleichen ----

# Die ersten beiden Anzahlen sollten 0 sein; fehlende Antworten sind möglich.
# ---- datenabgleich-vorschau ----
tibble(
  Fall = c("Antwort ohne Unit", "Antwort außerhalb Design",
           "Designzeile ohne Antwort"),
  Anzahl = c(nrow(unknown_units), nrow(outside_design), nrow(missing_rows))
) |> print()
# ---- /datenabgleich-vorschau ----

# 3. Automatisch kodieren
# code_id bezeichnet die Bewertung, code_score die Punktzahl.

# ---- automatisch-kodieren ----
coded_auto <- code_responses(responses, units, prepare = TRUE)
count(coded_auto, unit_key, code_status)
saveRDS(coded_auto, "checkpoints/02_coded_auto.rds")
# ---- /automatisch-kodieren ----

# U3/TOTAL sollte kodiert sein; U4/TEXT benötigt einen manuellen Code.
# ---- auto-vorschau ----
coded_auto |>
  filter(login_name == "P001", unit_key %in% c("U3", "U4")) |>
  select(unit_key, variable_id, code_id, code_score, code_status) |>
  head(4) |> print()
# ---- /auto-vorschau ----

# 4. Manuelle Codes ergänzen
# Ohne manuelle Codes genügt: coded <- coded_auto

# ---- manuelle-codes-einlesen ----
codes_manual <- readr::read_csv("data/codes_manual.csv",
  col_types = readr::cols(.default = "c", code_id = "i"))
# ---- /manuelle-codes-einlesen ----

# ---- manuelle-codes-vorschau ----
head(codes_manual, 3) |> print(width = 90) # sollte 7 Spalten zeigen
# ---- /manuelle-codes-vorschau ----

# Ursprüngliche Antworten erneut kodieren, einschließlich Ableitungen.
# ---- manuell-kodieren ----
coded <- code_responses(responses, units, prepare = TRUE,
                       codes_manual = codes_manual)
count(coded, code_status, code_type)
saveRDS(coded, "checkpoints/03_coded.rds")
# ---- /manuell-kodieren ----

# U4/TEXT sollte jetzt CODING_COMPLETE sein.
# ---- manuell-vorschau ----
coded |>
  filter(unit_key == "U4", variable_id == "TEXT") |>
  select(login_name, variable_id, code_id, code_score, code_status) |>
  head(4) |> print()
# ---- /manuell-vorschau ----

# 5. Testdesign ergänzen und Missings zuweisen
# Standard: Auslassung und ungültige Antwort erhalten 0, Not reached erhält NA.
# code_type enthält danach die Missing-Art; code_status bleibt erhalten.

# ---- design-ergaenzen ----
design_coded <- complete_design(coded, units, design,
  recode_omissions_to_not_reached = FALSE, preserve_not_reached = FALSE)

count(design_coded, id_used, code_type)
saveRDS(design_coded, "checkpoints/04_design_coded.rds")
# ---- /design-ergaenzen ----

# P002/U2: ausgelassen (0 Punkte). P003/U5: nicht erreicht (NA).
# ---- design-vorschau ----
design_coded |>
  filter((login_name == "P002" & unit_key == "U2") |
         (login_name == "P003" & unit_key == "U5")) |>
  select(login_name, unit_key, variable_id, code_type, code_score) |>
  print()
# ---- /design-vorschau ----

# Alternative: abschließende Auslassungen als nicht erreicht behandeln.
# Vorhandenes Not reached bleibt erhalten. Der Vergleich ist ein eigenes Objekt.

# ---- missing-regeln-vergleichen ----
omissions_reclassified <- complete_design(coded, units, design,
  recode_omissions_to_not_reached = TRUE, preserve_not_reached = TRUE)

count(omissions_reclassified, id_used, code_type)
# ---- /missing-regeln-vergleichen ----

# P006/U5 sollte mit der Alternative NA statt 0 Punkte erhalten.
# ---- missing-vergleich-vorschau ----
bind_rows(Standard = design_coded, Alternative = omissions_reclassified,
          .id = "Regel") |>
  filter(login_name == "P006", unit_key == "U5") |>
  select(Regel, login_name, unit_key, code_type, code_score) |>
  print()
# ---- /missing-vergleich-vorschau ----

# 6. Personen auswählen
# id_used: mindestens ein gespeicherter Kodierstatus ist vorhanden.

# ---- teilnahme-auswaehlen ----
analysis_data <- filter(design_coded, id_used)
count(design_coded, id_used)
# ---- /teilnahme-auswaehlen ----

# ---- teilnahme-vorschau ----
analysis_data |>
  select(login_name, unit_key, variable_id, id_used, code_score) |>
  head(4) |> print()
distinct(analysis_data, login_name) |>
  summarise(n_personen = n()) |> print() # sollte 39 Personen ergeben
# ---- /teilnahme-vorschau ----

# 7. Items zuordnen
# Variablen ohne Item-ID bleiben außerhalb des Skalierungsdatensatzes.

# ---- items-zuordnen ----
design_items <- add_item_id(design_coded, units)
item_data <- add_item_id(analysis_data, units)

unmapped <- item_data |>
  filter(is.na(item_id) | trimws(item_id) == "") |>
  distinct(unit_key, variable_id)
print(unmapped) # sollte U3/Q1 und U3/Q2 zeigen

item_data <- filter(item_data, !is.na(item_id), trimws(item_id) != "")
item_data <- mutate(item_data, item = paste0(unit_key, "__", item_id))
# ---- /items-zuordnen ----

# U3/TOTAL und U4/TEXT sind jeweils ein Item.
# ---- items-vorschau ----
item_data |>
  filter(login_name == "P001", unit_key %in% c("U3", "U4")) |>
  select(unit_key, variable_id, item_id, item, code_score) |>
  print()
# ---- /items-vorschau ----

# 8. Offene Itemkodierungen prüfen
# Bei einem Abbruch unresolved ansehen und die Kodierung klären.

# ---- offene-codes-pruefen ----
unresolved <- item_data |>
  filter(code_status %in% c("UNSET", "CODING_INCOMPLETE", "DERIVE_PENDING",
                           "CODING_ERROR", "DERIVE_ERROR",
                           "INTENDED_INCOMPLETE") |
         code_type %in% c("NO_CODING", "CODING_INCOMPLETE", "DERIVE_PENDING",
                          "INTENDED_INCOMPLETE"))
stopifnot(nrow(unresolved) == 0) # sollte ohne Fehler durchlaufen
# ---- /offene-codes-pruefen ----

# Sollte eine leere Tabelle ergeben.
# ---- offene-codes-vorschau ----
unresolved |>
  select(login_name, item, code_status, code_type) |>
  head(4) |> print()
# ---- /offene-codes-vorschau ----

# 9. Missing-Anteile berechnen
# n_items zählt vorgesehene Items; Aufgaben außerhalb des Designs zählen nicht.

# ---- missings-zusammenfassen ----
missing_summary <- summarise_missings(design_items)
missing_summary_used <- summarise_missings(design_items, used_only = TRUE)

select(missing_summary, all_of(person_columns), id_used, n_items,
       n_not_reached, n_by_omission, prop_missing)
readr::write_csv(missing_summary, "outputs/missing_summary.csv")
# ---- /missings-zusammenfassen ----

# ---- missing-uebersicht-vorschau ----
missing_summary |>
  select(login_name, n_items, n_not_reached, n_by_omission, prop_missing) |>
  head(4) |> print()
# ---- /missing-uebersicht-vorschau ----

# 10. Kennwerte berechnen
# Im Beispiel gehören alle Units zu Lesen; die Zuordnung für eigene Daten ändern.

# ---- kennwerte-berechnen ----
domains <- distinct(units, unit_key)
domains$domain <- "Lesen"

psychometrics <- evaluate_psychometrics(analysis_data, units, domains = domains)
psychometrics <- add_item_id(psychometrics, units)

code_stats <- psychometrics |>
  select(item_id, unit_key, variable_id, code_id, code_score,
         code_n, code_p_valid, code_pbc) |>
  distinct()
readr::write_csv(code_stats, "outputs/psychometrics.csv")
# ---- /kennwerte-berechnen ----

# ---- kennwerte-vorschau ----
code_stats |>
  filter(item_id == "U1_Q1") |>
  select(item_id, code_id, code_n, code_p_valid, code_pbc) |>
  head(4) |> print()
# ---- /kennwerte-vorschau ----

# Antwortkategorien unterscheiden die gewählten Antworten: A, B und C.
# ---- kennwerte-kategorien ----
category_stats <- psychometrics |>
  filter(item_id == "U1_Q1", !is.na(category_id)) |>
  select(category_id, code_id, category_n, category_p_valid, category_pbc)
print(category_stats) # sollte A: 21, B: 5 und C: 12 Antworten zeigen
# ---- /kennwerte-kategorien ----

# B und C erhalten denselben Code; distinct() entfernt wiederholte Codezeilen.
# ---- kennwerte-codes ----
code_stats_mc <- psychometrics |>
  filter(item_id == "U1_Q1") |>
  select(code_id, code_score, code_n, code_p_valid, code_pbc) |>
  distinct()
print(code_stats_mc) # sollte für Code 0 insgesamt 17 Antworten zeigen
# ---- /kennwerte-codes ----

# Scorehäufigkeiten direkt zählen; evaluate_psychometrics() liefert sie nicht.
# ---- kennwerte-scores ----
score_stats <- item_data |>
  filter(item_id == "U1_Q1") |>
  count(code_score, name = "score_n") |>
  mutate(score_p = score_n / sum(score_n))
print(score_stats) # sollte 18 Personen mit 0 und 21 mit 1 Punkt zeigen
# ---- /kennwerte-scores ----

# 11. Skalierungsdatensatz erstellen
# Eine Zeile pro Person, eine Spalte pro Item. NA bleibt erhalten.

# ---- score-datensatz-erstellen ----
scaling_data <- item_data |>
  select(group_id, login_name, login_code, item, code_score) |>
  pivot_wider(names_from = item, values_from = code_score) |>
  arrange(group_id, login_name, login_code) |>
  mutate(person_id = row_number(), .before = 1)
# ---- /score-datensatz-erstellen ----

# ---- datensatz-vorschau ----
scaling_data |>
  select(person_id, login_name, U1__U1_Q1, U3__U3_TOTAL, U5__U5_Q1) |>
  head(4) |> print()
# ---- /datensatz-vorschau ----

# View(scaling_data) # optional: die gesamte Tabelle in RStudio öffnen

# ---- datensatz-pruefen ----
person_key <- select(scaling_data, person_id, group_id, login_name, login_code)
item_columns <- setdiff(names(scaling_data), names(person_key))
persons <- distinct(item_data, group_id, login_name, login_code)
stopifnot(nrow(scaling_data) == nrow(persons))
stopifnot(all(vapply(scaling_data[item_columns], is.numeric, logical(1))))
# ---- /datensatz-pruefen ----

# Die Zuordnung der neuen person_id zu den Testcenter-Kennungen ansehen.
# ---- schluessel-vorschau ----
person_key |> head(4) |> print()
# ---- /schluessel-vorschau ----

# 12. Ergebnisse speichern
# Long-Daten enthalten auch Codes und Missing-Arten; person_key sichert die IDs.

# ---- daten-exportieren ----
readr::write_csv(scaling_data, "outputs/scaling_data.csv")
readr::write_csv(person_key, "outputs/person_key.csv")
saveRDS(analysis_data, "outputs/analysis_long.rds")
saveRDS(design_items, "outputs/design_items.rds")
saveRDS(scaling_data, "checkpoints/05_scaling_data.rds")

missing_counts <- count(design_coded, id_used, code_type)
readr::write_csv(missing_counts, "outputs/missing_counts.csv")
# ---- /daten-exportieren ----

# Sollte fünf vorhandene Dateien mit einer Größe über 0 Bytes zeigen.
# ---- export-vorschau ----
export_files <- c("scaling_data.csv", "person_key.csv", "analysis_long.rds",
                 "design_items.rds", "missing_counts.csv")
tibble(Datei = export_files,
       Bytes = file.info(file.path("outputs", export_files))$size) |> print()
# ---- /export-vorschau ----

# 13. Aufbereitung dokumentieren
# Nach Änderungen an Auswahl oder Missing-Regeln die Angaben unten anpassen.

# ---- workflow-dokumentieren ----
report <- c(
  "Workflow erfolgreich ausgeführt; allgemeine Prüfungen bestanden.",
  paste("eatPrepTBA:", packageVersion("eatPrepTBA")),
  paste("eatAutoCode:", packageVersion("eatAutoCode")),
  paste("Units:", nrow(units)),
  paste("Designzeilen:", nrow(design)),
  paste("Antwortzeilen:", nrow(responses)),
  paste("Personen im Export:", nrow(scaling_data)),
  paste("Itemspalten:", length(item_columns)),
  "Missing-Regeln: Paketvoreinstellungen; beide NR-Optionen FALSE.",
  "Auswahl: id_used = TRUE; verknüpfte Itemvariablen.",
  "Keine offenen Itemkodierungen im exportierten Datensatz.",
  "Fehlende Werte bleiben NA; Long-Daten und Personenschlüssel gesichert.")

writeLines(report, "outputs/validation.txt", useBytes = TRUE)
capture.output(sessionInfo(), file = "outputs/session-info.txt")
cat(paste(report, collapse = "\n"), "\n")
# ---- /workflow-dokumentieren ----

# Weiterarbeiten: R/04_logs.R und R/05_kodiermanuale.R separat ausführen.
